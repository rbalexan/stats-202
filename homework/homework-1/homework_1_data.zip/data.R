setwd("/Users/tranlm/Google Drive/2020-2021 Q4/hw/hw1/data")

# Ch10 Q9
data(USArrests)
write.csv(USArrests, file='./USArrests.csv')

#Ch3 Q9
data(Auto)
write.csv(Auto, file='./Auto.csv', row.names=FALSE)

#Ch3 Q14
set.seed(1)
x1 <- runif(100)
x2 <- 0.5 * x1 + rnorm(100) / 10
y <- 2 + 2 * x1 + 0.3 * x2 + rnorm(100)
O <- data.frame(x1, x2, y)
write.csv(O, file='./ch3_q14_simulation.csv', row.names=FALSE)
